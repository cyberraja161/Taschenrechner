import java.util.Scanner;

public class Maschine
{
    public void Sprachenauswahl()
    {
        System.out.println("Casio FX - made by Prince");
        Scanner scan = new Scanner(System.in);
        System.out.println("In welcher Sprache möchten Sie die Maschine benützen? Bitte eingeben!");
        System.out.println("In which language would you like to use the machine? Please enter!");
        System.out.println("1 - für Deutsch");
        System.out.println("2 - for English");
        int eingabe = scan.nextInt();
        if(eingabe > 2 || eingabe < 1)
        {
            eingabe = 1;
        }
        switch (eingabe)
        {
            case 1: deutsch();
            case 2: english();
        }
    }

    public void deutsch()
    {
        System.out.println("Casio Fx - German Version - made by Basra");
        System.out.println("Bitte geben Sie ihre Rechung ein! (zur Auswahl +, -, :, *, Quadratzahlen bzw.Hochzahlen Alt Gr Tastenkombi anwenden!");
        Scanner scan2 = new Scanner(System.in);
        System.out.println("Geben Sie die erste Ziffer ein mit der Sie rechnen wollen!");
        double eingabe1 = scan2.nextDouble();
        System.out.println("Geben Sie bitte jetzt den gewünschten Operator! Auswahl -> +, -, :, *, Quadratzahlen bzw.Hochzahlen Alt Gr Tastenkombi anwenden!, fürs Wurzelziehen dieses Zeichen benützen: √ ");
        String eingabeoperator = scan2.next();
        System.out.println("Geben Sie die zweite Ziffer ein mit der Sie rechnen wollen!");
        double eingabe2 = scan2.nextDouble();
        rechner(eingabeoperator, eingabe1, eingabe2);
    }

    public void english() {
        System.out.println("Casio Fx - English Version - made by Basra");
        System.out.println("Please enter an invoice for your choice! (to select +, -, :, *, square numbers or exponents, use Alt Gr key combination, Use this symbol to extract roots: √");
        Scanner scan3 = new Scanner(System.in);
        System.out.println("Enter the first digit you want to calculate!");
        double eingabe3 = scan3.nextDouble();
        System.out.println("Please enter the operator you want to use: +, -, :, *, squares, or powers (use the Alt Gr key)");
        String eingabeoperator2 = scan3.next();
        System.out.println("Enter the second digit you want to calculate!");
        double eingabe4 = scan3.nextDouble();
        calculator(eingabeoperator2, eingabe3, eingabe4);
    }

    public void calculator(String eingabeoperator1, double eingabe3, double eingabe4)
    {
        switch (eingabeoperator1)
        {
            case "+":
                System.out.println(eingabe3+eingabe4);
                break;
            case "-":
                System.out.println(eingabe3-eingabe4);
                break;
            case "*":
                System.out.println(eingabe3*eingabe4);
                break;
            case ":":
                System.out.println(eingabe3/eingabe4);
                break;
        }
    }

    public void rechner(String eingabeoperator, double eingabe1,double eingabe2)
    {
        switch (eingabeoperator)
        {
            case "+":
                System.out.println(eingabe1+eingabe2);
                System.out.println("Fürs ausschalten der Maschine melden mit dem Befehl off!");
                Scanner scan4 = new Scanner(System.in);
                String ausschaltenodernicht = scan4.nextLine();
                if(ausschaltenodernicht.contains("off") || ausschaltenodernicht.equals("Off"))
                {
                    break;
                }
                else
                {
                    Sprachenauswahl();
                }

            case "*":
                System.out.println(eingabe1*eingabe2);
                System.out.println("Fürs ausschalten der Maschine melden mit dem Befehl off!");
                Scanner scan5 = new Scanner(System.in);
                String ausschaltenodernicht3 = scan5.nextLine();
                if(ausschaltenodernicht3.contains("off") || ausschaltenodernicht3.equals("Off"))
                {
                    break;
                }
                else
                {
                    Sprachenauswahl();
                }
                break;

            case "-":
                System.out.println(eingabe1-eingabe2);
                System.out.println("Fürs ausschalten der Maschine melden mit dem Befehl off!");
                Scanner scan6 = new Scanner(System.in);
                String ausschaltenodernicht4 = scan6.nextLine();
                if(ausschaltenodernicht4.contains("off") || ausschaltenodernicht4.equals("Off"))
                {
                    break;
                }
                else
                {
                    Sprachenauswahl();
                }
                break;

            case ":":
                System.out.println(eingabe1/eingabe2);
                System.out.println("Fürs ausschalten der Maschine melden mit dem Befehl off!");
                Scanner scan7 = new Scanner(System.in);
                String ausschaltenodernicht5 = scan7.nextLine();
                if(ausschaltenodernicht5.contains("off") || ausschaltenodernicht5.equals("Off"))
                {
                    break;
                }
                else
                {
                    Sprachenauswahl();
                }
                break;

            case "√":
                System.out.println(Math.sqrt(eingabe1));
                Scanner scan8 = new Scanner(System.in);
                String ausschaltenodernicht6 = scan8.nextLine();
                if(ausschaltenodernicht6.contains("off") || ausschaltenodernicht6.equals("Off"))
                {
                    break;
                }
                else
                {
                    Sprachenauswahl();
                }
                break;
            default:
                System.err.println("Sie haben den Befehl flasch eingegeben!!");
                rechner(eingabeoperator, eingabe1, eingabe2);
        }
    }
}
