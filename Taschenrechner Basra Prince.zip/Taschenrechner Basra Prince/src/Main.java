public class Main
{
    public static void main(String[] args)
    {
        Maschine test = new Maschine();
        test.Sprachenauswahl();
    }
}